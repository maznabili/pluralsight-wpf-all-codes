﻿using Common.Library;

namespace WPF.Sample.ViewModelLayer
{
  public class LoginViewModel : ViewModelBase
  {
  }
}
