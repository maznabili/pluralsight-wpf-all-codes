﻿using System.Windows;
using System;
using System.Windows.Threading;
using System.Threading.Tasks;
using WPF.Sample.ViewModelLayer;

namespace WPF.Sample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();

      // Connect to instance of the view model created by the XAML
      _viewModel = (MainWindowViewModel)this.Resources["viewModel"];
    }

    // Main window's view model class
    private MainWindowViewModel _viewModel = null;

    private void MenuItem_Click(object sender, RoutedEventArgs e)
    {
    }

    private async void Window_Loaded(object sender, RoutedEventArgs e)
    {
      // Call method to load resources application
      await LoadApplication();

      // Turn off informational message area
      _viewModel.ClearInfoMessages();
    }

    public async Task LoadApplication()
    {
      _viewModel.InfoMessage = "Loading State Codes...";
      await Dispatcher.BeginInvoke(new Action(() => {
        _viewModel.LoadStateCodes();
      }), DispatcherPriority.Background);

      _viewModel.InfoMessage = "Loading Country Codes...";
      await Dispatcher.BeginInvoke(new Action(() => {
        _viewModel.LoadCountryCodes();
      }), DispatcherPriority.Background);

      _viewModel.InfoMessage = "Loading Employee Types...";
      await Dispatcher.BeginInvoke(new Action(() => {
        _viewModel.LoadEmployeeTypes();
      }), DispatcherPriority.Background);
    }

  }
}
