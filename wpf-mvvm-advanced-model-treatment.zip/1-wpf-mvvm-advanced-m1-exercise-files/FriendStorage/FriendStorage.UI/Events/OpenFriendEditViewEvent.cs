﻿using Microsoft.Practices.Prism.PubSubEvents;

namespace FriendStorage.UI.Events
{
  public class OpenFriendEditViewEvent : PubSubEvent<int>
  {
  }
}
