﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace DragDropDataBinding
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindowMVVM : Window
    {
        public MainWindowMVVM()
        {
            InitializeComponent();
        }
    }
}
