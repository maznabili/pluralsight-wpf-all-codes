namespace FriendStorage.UI.DataProvider.Lookups
{
  public class LookupItem
  {
    public int Id { get; set; }

    public string DisplayValue { get; set; }
  }
}