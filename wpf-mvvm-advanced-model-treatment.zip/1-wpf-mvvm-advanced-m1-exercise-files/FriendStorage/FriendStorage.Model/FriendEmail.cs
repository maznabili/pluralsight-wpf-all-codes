﻿namespace FriendStorage.Model
{
  public class FriendEmail
  {
    public int Id { get; set; }

    public string Email { get; set; }

    public string Comment { get; set; }
  }
}