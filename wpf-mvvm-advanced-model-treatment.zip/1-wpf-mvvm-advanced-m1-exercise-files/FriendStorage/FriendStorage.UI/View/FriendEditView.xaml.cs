﻿using System.Windows.Controls;

namespace FriendStorage.UI.View
{
  public partial class FriendEditView : UserControl
  {
    public FriendEditView()
    {
      InitializeComponent();
    }
  }
}
