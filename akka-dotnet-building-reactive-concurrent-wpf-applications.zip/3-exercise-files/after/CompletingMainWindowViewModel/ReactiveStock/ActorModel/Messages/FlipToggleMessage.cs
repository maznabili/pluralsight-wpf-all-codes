﻿namespace ReactiveStock.ActorModel.Messages
{
    class FlipToggleMessage{}
}
