﻿WPF.Sample.DataLayer
------------------------------------------
Add any classes that access data in this project.
