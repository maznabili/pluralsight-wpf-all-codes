﻿using Microsoft.Practices.Prism.PubSubEvents;

namespace FriendStorage.UI.Events
{
  public class FriendDeletedEvent : PubSubEvent<int>
  {
  }
}