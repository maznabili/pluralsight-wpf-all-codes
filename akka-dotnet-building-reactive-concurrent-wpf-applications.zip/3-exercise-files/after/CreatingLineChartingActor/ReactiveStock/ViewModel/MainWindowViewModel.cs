using GalaSoft.MvvmLight;

namespace ReactiveStock.ViewModel
{
    public class MainWindowViewModel : ViewModelBase
    {
        public MainWindowViewModel()
        {

        }
    }
}