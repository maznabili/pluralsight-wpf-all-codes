﻿namespace Globomantics.TeRex.Models
{
    public class Project
    {
        public string Id { get; set; }
        public string DisplayName { get; set; }
    }
}
