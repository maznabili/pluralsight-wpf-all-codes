﻿using System.Windows.Controls;

namespace Globomantics.TeRex.Views
{
    public partial class TeRexView : UserControl
    {
        public TeRexView()
        {
            InitializeComponent();
        }
    }
}
