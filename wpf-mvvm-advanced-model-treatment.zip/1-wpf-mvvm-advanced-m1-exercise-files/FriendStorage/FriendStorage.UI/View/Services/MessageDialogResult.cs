﻿namespace FriendStorage.UI.View.Services
{
  public enum MessageDialogResult
  {
    Yes,
    No,
    Ok,
  }
}