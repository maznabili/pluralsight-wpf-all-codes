﻿using System.Windows;

namespace BlendVisualStates
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public bool IsOpen
        {
            get { return (bool)GetValue(IsOpenProperty); }
            set { SetValue(IsOpenProperty, value); }
        }

        public static readonly DependencyProperty IsOpenProperty =
            DependencyProperty.Register("IsOpen", typeof(bool), typeof(MainWindow), new PropertyMetadata(false));

        public void ToggleIsOpen()
        {
            IsOpen = !IsOpen;
        }
    }
}
