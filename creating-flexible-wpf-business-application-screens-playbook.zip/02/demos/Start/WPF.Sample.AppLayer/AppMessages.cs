﻿using Common.Library;

namespace WPF.Sample.AppLayer
{
  /// <summary>
  /// This class is for application-specific message broker messages
  /// </summary>
  public class AppMessages : MessageBrokerMessages
  {
  }
}
