﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace DataTemplates
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
