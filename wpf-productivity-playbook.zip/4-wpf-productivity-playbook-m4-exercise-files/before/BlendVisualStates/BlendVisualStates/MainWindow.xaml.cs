﻿using System.Windows;

namespace BlendVisualStates
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
