﻿namespace Globomantics.UI.WPF
{
    public enum ThemeType
    {
        Light,
        Dark
    }
}