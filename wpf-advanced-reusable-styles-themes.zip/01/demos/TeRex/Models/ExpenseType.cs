﻿namespace Globomantics.TeRex.Models
{
    public class ExpenseType
    {
        public string Id { get; set; }
        public string DisplayName { get; set; }
    }
}
